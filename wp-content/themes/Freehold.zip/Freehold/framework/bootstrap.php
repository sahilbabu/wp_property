<?php
// Metaboxes
get_template_part( 'framework/metaboxes' );
get_template_part( 'framework/profile' );
?>