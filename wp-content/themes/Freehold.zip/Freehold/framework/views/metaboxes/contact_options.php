<div class='pyre_metabox'>
<?php
$this->textarea(	'map',
				'Address',
				''
			);
?>
<?php
$this->text(	'email',
				'Email Address',
				''
			);
?>
</div>