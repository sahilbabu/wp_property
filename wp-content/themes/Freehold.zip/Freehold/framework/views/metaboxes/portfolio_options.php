<?php
$this->text(	'video_link',
				'Video Link',
				'Paste in your video link here.'
			);
$this->textarea(	'video_embed_code',
				'Video Embed Code',
				'Paste in your video embed code.'
			);
$this->text(	'portfolio_external_link',
			'Link to another page',
			'Link your portfolio index post to another web-page.'
			);

?>