					<form method="get" class="searchform" action="<?php echo home_url(); ?>/">
						<label for="s" class="assistive-text"><?php _e('Search','progressionstudios'); ?>:</label>
						<input type="text" class="field" name="s" id="s" placeholder="<?php _e('Search our blog...','progressionstudios'); ?>" />
						<input type="submit" class="submit" name="submit" id="searchsubmit" value="Search" />
					</form>