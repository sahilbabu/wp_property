<?php get_header(); ?>
	<div id="main">
		<div class="width-container">


				<div class="content-boxed">
					

					<h2 class="title-bg">Theme shared on W P L O C K E R .C O M <?php echo of_get_option('404_error', '404 Page Not Found'); ?></h2>
<br>
						
					<div class="404-error">
					<?php echo of_get_option('404_error_text', 'The page you are looking is not available. You can customize this text in the Theme Options Panel'); ?>
					</div>
					<br>							
						<div class="clearfix"></div>

				

				<div class="clearfix"></div>
				</div><!-- close .content-boxed -->
				
				
				<div class="clearfix"></div>
				
	
			
			
		<div class="clearfix"></div>
		</div><!-- close .width-container -->
	</div><!-- close #main -->
<?php get_footer(); ?>